// Front-end JS converted from google.script.run to fetch API
const btnPagar = document.getElementById("btnPagar");
const btnReset = document.getElementById("btnReset");
const mensaje = document.getElementById("mensaje");
const fechaInput = document.getElementById("fecha");
const horaSelect = document.getElementById("hora");
const overlay = document.getElementById("overlay");

const RES_EXPIRATION_MIN = 30; // keep same default

(function setMinDate(){
  const today = new Date();
  const yyyy = today.getFullYear();
  const mm = String(today.getMonth()+1).padStart(2,'0');
  const dd = String(today.getDate()).padStart(2,'0');
  fechaInput.setAttribute('min', `${yyyy}-${mm}-${dd}`);
})();

function mostrarMensaje(texto, tipo="wait") {
  mensaje.textContent = texto;
  mensaje.classList.remove('success', 'error', 'wait');
  if (tipo === 'success') mensaje.classList.add('success');
  else if (tipo === 'error') mensaje.classList.add('error');
  else mensaje.classList.add('wait');

  mensaje.style.opacity = 1;
  setTimeout(() => { mensaje.style.opacity = 0.95 }, 10);

  clearTimeout(mostrarMensaje._t);
  mostrarMensaje._t = setTimeout(() => { mensaje.textContent = ''; mensaje.style.opacity=0 }, 6000);
}

function showLoader() { overlay.classList.add('show'); }
function hideLoader() { overlay.classList.remove('show'); }

btnReset.addEventListener('click', () => {
  document.getElementById('reservaForm').reset();
  for (let o of horaSelect.options) { o.disabled = false; o.style.color='black'; }
  mostrarMensaje('Formulario limpiado', 'wait');
});

btnPagar.addEventListener('click', async function() {
  const nombre = document.getElementById('nombre').value.trim();
  const fecha = fechaInput.value;
  const hora = horaSelect.value;
  const tipo = document.getElementById('tipo').value;

  if (!nombre || !fecha || !hora || !tipo) {
    mostrarMensaje('Completá todos los campos.', 'error');
    return;
  }

  btnPagar.disabled = true;
  btnReset.disabled = true;
  showLoader();

  try {
    const resp = await fetch('/api/crearPago', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ nombre, fecha, hora, tipo })
    });

    const respuesta = await resp.text();

    hideLoader();
    btnPagar.disabled = false;
    btnReset.disabled = false;

    if(respuesta === "error_fecha") {
      mostrarMensaje("No se puede reservar una fecha pasada.", "error");
      return;
    }

    if(respuesta === "occupied") {
      mostrarMensaje("Ese turno ya fue reservado.", "error");
      fechaInput.dispatchEvent(new Event('change'));
      return;
    }

    if(respuesta === "error") {
      mostrarMensaje("Error al generar el pago. Intentá otra vez.", "error");
      return;
    }

    // respuesta is URL to payment init_point
    window.open(respuesta, "_blank");
    mostrarMensaje("Link generado. Completá el pago para confirmar tu turno.", "success");

  } catch (e) {
    hideLoader();
    btnPagar.disabled = false;
    btnReset.disabled = false;
    mostrarMensaje('Error de conexión. Revisá tu internet.', 'error');
  }
});
